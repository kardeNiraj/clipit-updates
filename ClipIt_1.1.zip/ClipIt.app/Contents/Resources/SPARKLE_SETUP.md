# Sparkle Setup (ClipIt)

This project is now Sparkle-ready in code via `Services/UpdateManager.swift`.

## 1) Add Sparkle package in Xcode
- Open project settings → `Package Dependencies` → `+`.
- Add: `https://github.com/sparkle-project/Sparkle`
- Use latest stable release.
- Link `Sparkle` product to the `ClipIt` app target.

## 2) Add appcast feed URL
- In target `Info` (or `Info.plist`), set Sparkle feed key:
  - `SUFeedURL` = your hosted `appcast.xml` URL

## 3) Add public EdDSA key
- Generate Sparkle keys and add:
  - `SUPublicEDKey` in `Info.plist`

## 4) Archive signing/notarization
- Keep normal Developer ID signing + notarization flow.
- Publish notarized `.zip`/`.dmg` and update appcast entries.

## 5) Verify in app
- Menu bar item: `Check for Updates…`
- Settings → General → `Check for Updates…`

If Sparkle is not linked, UI stays safe and disabled with a hint.
