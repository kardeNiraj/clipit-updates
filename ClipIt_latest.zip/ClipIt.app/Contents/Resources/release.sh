#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Define directories relative to the script location
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
UPDATES_DIR="/Users/nirajkarde/Desktop/Personal_Projects/ClipIt-updates"
BUILD_DIR="$PROJECT_DIR/build"
SPARKLE_GEN_APPCAST="$SCRIPT_DIR/sparkle_bin/generate_appcast"

# Color formatting for terminal outputs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Starting ClipIt Automated Release Pipeline ===${NC}"

# Step 1: Verify pre-requisites
if [ ! -d "$UPDATES_DIR" ]; then
    echo -e "${YELLOW}Creating updates directory at $UPDATES_DIR...${NC}"
    mkdir -p "$UPDATES_DIR"
fi

if [ ! -f "$SPARKLE_GEN_APPCAST" ]; then
    echo -e "${RED}Error: generate_appcast binary not found at $SPARKLE_GEN_APPCAST${NC}"
    exit 1
fi

# Step 2: Clean and compile Release build with automated monotonic Build Version
AUTO_BUILD_VERSION=$(date "+%Y%m%d%H%M")
echo -e "${BLUE}[1/5] Compiling fresh Release build of ClipIt (Auto Build: ${AUTO_BUILD_VERSION})...${NC}"
xcodebuild \
    -project "$PROJECT_DIR/ClipIt.xcodeproj" \
    -scheme ClipIt \
    -configuration Release \
    -derivedDataPath "$BUILD_DIR" \
    CURRENT_PROJECT_VERSION="$AUTO_BUILD_VERSION" \
    clean build

APP_PATH="$BUILD_DIR/Build/Products/Release/ClipIt.app"

if [ ! -d "$APP_PATH" ]; then
    echo -e "${RED}Error: Release build failed. ClipIt.app was not produced.${NC}"
    exit 1
fi

# Step 3: Parse Version from built Info.plist
echo -e "${BLUE}[2/5] Parsing version details...${NC}"
VERSION=$(defaults read "$APP_PATH/Contents/Info.plist" CFBundleShortVersionString)
BUILD=$(defaults read "$APP_PATH/Contents/Info.plist" CFBundleVersion)
ZIP_NAME="ClipIt_${VERSION}.zip"

echo -e "${GREEN}Detected Version: $VERSION (Build $BUILD)${NC}"
echo -e "${GREEN}Target Zip File: $ZIP_NAME${NC}"

# Step 4: Copy and Package to the Updates Folder
echo -e "${BLUE}[3/5] Moving and zipping app bundle to updates directory...${NC}"
rm -rf "$UPDATES_DIR/ClipIt.app"
rm -f "$UPDATES_DIR/$ZIP_NAME"
rm -f "$UPDATES_DIR/ClipIt_latest.zip"

cp -R "$APP_PATH" "$UPDATES_DIR/"

# Zip using Apple's compliant ditto tool (preserves resource forks and permissions)
cd "$UPDATES_DIR"
ditto -c -k --sequesterRsrc --keepParent ClipIt.app "$ZIP_NAME"

# Clean up raw app in updates folder to keep it lightweight
rm -rf ClipIt.app

echo -e "${GREEN}Successfully packaged update package inside $UPDATES_DIR${NC}"

# Step 5: Regenerate and Sign the Sparkle Appcast
echo -e "${BLUE}[4/5] Regenerating signed appcast.xml...${NC}"
"$SPARKLE_GEN_APPCAST" "$UPDATES_DIR/"

echo -e "${GREEN}appcast.xml has been successfully signed and updated!${NC}"

# Step 5.5: Refresh the stable ClipIt_latest.zip for external direct linking
echo -e "${BLUE}Refreshing stable ClipIt_latest.zip package for direct download platforms...${NC}"
cp "$UPDATES_DIR/$ZIP_NAME" "$UPDATES_DIR/ClipIt_latest.zip"
echo -e "${GREEN}ClipIt_latest.zip updated successfully!${NC}"

# Step 6: Git Auto-Push Option
echo -e "${BLUE}[5/5] Checking Git repository status in updates folder...${NC}"
if [ -d "$UPDATES_DIR/.git" ]; then
    echo -e "${YELLOW}Updates directory is a Git repository!${NC}"
    read -p "Would you like to automatically commit and push these updates to GitHub? (y/n): " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        git add appcast.xml "$ZIP_NAME" "ClipIt_latest.zip"
        git commit -m "Release ClipIt Version $VERSION (Build $BUILD)"
        echo -e "${BLUE}Pushing to GitHub main...${NC}"
        git push origin main || git push origin master
        echo -e "${GREEN}Successfully pushed updates to GitHub!${NC}"
    else
        echo -e "${YELLOW}Skipped Git push. You can commit and push manually when ready.${NC}"
    fi
else
    echo -e "${YELLOW}Git repository not found in $UPDATES_DIR. Skipping Git push.${NC}"
fi

# Clean up build directory to save local space
echo -e "${BLUE}Cleaning up local build cache...${NC}"
rm -rf "$BUILD_DIR"

echo -e "${GREEN}=== Release Process Completed Successfully! ===${NC}"
