#!/bin/bash

# Setup Sparkle CLI tools and generate keys for ClipIt (Hobby Project / Ad-hoc signed)
# This script downloads Sparkle 2.9.1 CLI tools and generates EdDSA keys for secure updates.

set -e

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="${PROJECT_ROOT}/sparkle_bin"
TEMP_DIR="${PROJECT_ROOT}/sparkle_temp"

echo "================================================================="
echo "🚀 Setting up Sparkle 2.9.1 CLI Tools & EdDSA Keys for ClipIt"
echo "================================================================="

# Create directories
mkdir -p "${BIN_DIR}"
mkdir -p "${TEMP_DIR}"

# Download Sparkle release archive if not already done
SPARKLE_TAR="${TEMP_DIR}/Sparkle-2.9.1.tar.xz"
if [ ! -f "${SPARKLE_TAR}" ]; then
    echo "📥 Downloading Sparkle 2.9.1 distribution archive..."
    curl -L "https://github.com/sparkle-project/Sparkle/releases/download/2.9.1/Sparkle-2.9.1.tar.xz" -o "${SPARKLE_TAR}"
else
    echo "📦 Sparkle 2.9.1 archive already downloaded."
fi

# Extract generate_keys and generate_appcast tools
echo "📦 Extracting CLI tools to sparkle_bin/..."
tar -xf "${SPARKLE_TAR}" -C "${TEMP_DIR}"
cp "${TEMP_DIR}/bin/generate_keys" "${BIN_DIR}/"
cp "${TEMP_DIR}/bin/generate_appcast" "${BIN_DIR}/"

# Clean up temp folder
rm -rf "${TEMP_DIR}"

echo "✅ CLI tools successfully extracted to: ${BIN_DIR}/"
echo "   - generate_keys: Generates EdDSA public and private keys"
echo "   - generate_appcast: Automatically generates update feed XML"

echo ""
echo "================================================================="
echo "🔑 Generating EdDSA Update Signing Keys"
echo "================================================================="

# Run generate_keys to create key pair.
# This tool automatically registers the private key in your macOS Keychain.
# It outputs the public key to stdout, which we will parse.
cd "${BIN_DIR}"
echo "Running generate_keys..."
KEYS_OUTPUT=$(./generate_keys)

# Parse public key from output (Format is usually "SUPublicEDKey: <key-string>")
PUBLIC_KEY=$(echo "${KEYS_OUTPUT}" | grep "SUPublicEDKey" | awk '{print $2}' || true)

if [ -z "${PUBLIC_KEY}" ]; then
    # Sometimes it prints only the public key string or format changes.
    PUBLIC_KEY=$(echo "${KEYS_OUTPUT}" | sed -n 's/.*"\(.*\)".*/\1/p' || true)
fi

# If we couldn't parse it automatically, output the full result
echo ""
echo "📝 Key generation output:"
echo "-----------------------------------------------------------------"
echo "${KEYS_OUTPUT}"
echo "-----------------------------------------------------------------"
echo ""

# Write public key to a local helper file for reference
echo "${PUBLIC_KEY}" > "${PROJECT_ROOT}/sparkle_public_key.txt"

echo "🎉 Success!"
echo "Your private key has been stored SECURELY in your Mac's Keychain."
echo "Your public key is: ${PUBLIC_KEY}"
echo "It has also been written to: sparkle_public_key.txt"
echo ""
echo "💡 NEXT STEPS FOR YOUR HOBBY PROJECT (No Apple Developer ID):"
echo "1. Update the 'SUPublicEDKey' value in 'ClipIt/Config/Info.plist' with this new public key."
echo "2. Build the ClipIt app in Xcode as a Release version (Product -> Archive -> Distribute App -> Copy App)."
echo "3. Compress your compiled 'ClipIt.app' into a ZIP file (e.g., 'ClipIt_1.1.0.zip')."
echo "4. Place the ZIP file inside your hosted updates folder (e.g., your GitHub Pages repository)."
echo "5. Generate your update appcast XML by running:"
echo "   ./sparkle_bin/generate_appcast path/to/your/updates/folder/"
echo "6. Commit and push the generated 'appcast.xml' and 'ClipIt_1.1.0.zip' to GitHub Pages!"
echo "================================================================="
