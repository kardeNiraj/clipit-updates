# Sparkle Integration Complete Walkthrough

We have successfully integrated, configured, and streamlined the Sparkle 2 update system for ClipIt.

Because ClipIt is a sandboxed application and you are developing it as a hobby project (without a paid Apple Developer ID), we have implemented a tailored setup that allows secure update distribution without notarization or active Developer ID signatures.

---

## What Has Been Done

1. **Configured App Sandbox Exceptions**:
   - Modified `Config/Entitlements.plist` to add Sparkle's Mach lookup exceptions (`com.example.nkarde.ClipIt-spks` and `com.example.nkarde.ClipIt-spki`) and the Outgoing Connections (`com.apple.security.network.client`) entitlement so Sparkle can safely perform update lookups outside the sandbox.
2. **Activated Installer Launcher**:
   - Modified `Config/Info.plist` to set `SUEnableInstallerLauncherService` to `true`. This enables the necessary helper XPC service required to install updates outside of the sandbox.
3. **Automated CLI Tools and Key Setup**:
   - Created and executed a customized [setup_sparkle.sh](file:///Users/nirajkarde/Desktop/Personal_Projects/ClipIt/ClipIt/ClipIt/setup_sparkle.sh) shell script inside your workspace.
   - The script automatically downloaded the official Sparkle 2.9.1 CLI tools into a local `sparkle_bin` directory.
   - It ran Sparkle's key generator, which successfully verified that your EdDSA public key (`0akrynxFrOCczZjqOTjjT9EhfdB+jSh1/Hxd6niBVqo=`) is already perfectly matched to your local macOS Keychain!

---

## Guide: How to Release & Test Updates From Scratch (Hobby Project Style)

Since you do not have a paid Apple Developer ID, follow this exact step-by-step workflow to test updates locally and deploy them to GitHub Pages.

### Step 1: Build the Release App
1. Open your project in Xcode.
2. Select **Product -> Build** (or select **Product -> Archive** if you want to generate an archive).
3. Find your built `ClipIt.app` (it will be inside Xcode's DerivedData or your compiled products directory).

### Step 2: Prepare the Update Folder & Zip
1. Create a folder on your Mac where you will manage your updates (e.g., `/Users/nirajkarde/Desktop/ClipIt-updates`).
2. Compress `ClipIt.app` into a `.zip` file.
   - Name it indicating its version (e.g., `ClipIt_1.1.0.zip`).
3. Place `ClipIt_1.1.0.zip` inside your updates folder.

### Step 3: Generate and Sign the Appcast XML
1. Open your terminal and navigate to your `ClipIt` project directory:
   ```bash
   cd /Users/nirajkarde/Desktop/Personal_Projects/ClipIt/ClipIt/ClipIt
   ```
2. Run Sparkle's `generate_appcast` tool, pointing it to your updates folder:
   ```bash
   ./sparkle_bin/generate_appcast /Users/nirajkarde/Desktop/ClipIt-updates/
   ```
3. **What this does**:
   - It scans the updates folder for zip files.
   - It accesses your private key in the Keychain to generate a secure EdDSA signature.
   - It outputs a perfectly formatted `appcast.xml` containing the signature and download link.

### Step 4: Local Testing (Before Publishing)
1. You can verify that your Sparkle updater works locally by starting a mini web server inside your updates folder:
   ```bash
   cd /Users/nirajkarde/Desktop/ClipIt-updates
   python3 -m http.server 8080
   ```
2. In Xcode, temporarily modify `SUFeedURL` inside `Config/Info.plist` or project build settings to point to:
   `http://localhost:8080/appcast.xml`
3. Launch ClipIt, open **Settings -> General**, and click **Check for Updates...** to test the update popup locally!

### Step 5: Distribute via GitHub Pages
1. Once satisfied, upload your `appcast.xml` and `ClipIt_1.1.0.zip` to your GitHub Pages repository:
   - Git repository: `kardeNiraj/clipit-updates`
2. Change the `SUFeedURL` back to your production address:
   `https://kardeNiraj.github.io/clipit-updates/appcast.xml`
3. Now, whenever you want to release a new update, simply repeat Steps 1-3, push the updated files to GitHub, and your users will instantly receive the updates!
